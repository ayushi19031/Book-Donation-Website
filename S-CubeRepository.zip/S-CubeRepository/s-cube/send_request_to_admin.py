import os
# os.environ["GOOGLE_APPLICATION_CREDENTIALS"]= "C:\Users\ayush\Downloads\S-Cube-2cf7c24fcb1b.json"
import firebase_admin
from firebase_admin import db
from firebase_admin import auth
from firebase_admin import credentials
from google.cloud import firestore
from flask import *;
import datetime
import logging
import firebase

import argparse
import json
import os
import requests
import pprint
import sign_in_with_email_and_password

app = Flask(__name__)

firebase_admin.initialize_app(options={
    'databaseURL': 'https://fir-cube-282109.firebaseio.com/'
})

uid = 'some-uid'
additional_claims = {
    'admin': True
}
claims = auth.create_custom_token("CcFyHibh2BSHG6wM0rFolpAeiKg2", {"admin": True})
print(auth.get_user("CcFyHibh2BSHG6wM0rFolpAeiKg2").custom_claims)



QUERIES = db.reference('queries')
QNAME = db.reference('queries/emailid/name');
QEMAILID = db.reference('queries/emailid')
QBOOKID = db.reference('queries/emailid/bookid')
QPURCHASETYPE =  db.reference('queries/emailid/purchaseType')


BOOK_STATUS = db.reference('bookid/bookstatus');
NAME_OF_BOOK = db.reference('bookid/bookname')
BOOK_ID = db.reference('bookid')
RENT_OR_PURCHASE_OR_BOTH = db.reference("bookid/book_status/RorP")

BOOK_DETAILS = db.reference("BOOKS")


@app.route('/', methods = ['GET'])
def basic():
    return render_template("index.html")

@app.route('/sendaWish', methods = ['GET', 'POST'])
def sendtoDB():
    if request.method == 'GET':
        dr = BOOK_DETAILS.get()
        uid = request.cookies.get("uid", "")
        if uid:
            return render_template("index.html", dr = dr);
        else:
            print(uid)
        #    return redirect("/adminLogin")
            #if uid != "":
    #        user = auth.get_user(uid)
        #    print(user.email)
            return render_template("index.html", dr = dr);


    if request.method == 'POST':

        global send_a_wish
        name = request.form['name'].strip()
        email = request.form['emailid'].strip()
        bookid = request.form['bookid'].strip()
        purchaseType = request.form['purchaseType'].strip()
        QUERIES.push({
        'email': email,
        'bookid': bookid,
        'purchaseType': purchaseType
        })
        dr = BOOK_DETAILS.get()
        # for key in dr:
        #     if dr[key][bookid] == bookid and dr[key][stock] == 0:
        #         return render_template("not_here.html")

        print("Yayyy")
        return render_template("index.html", dr  = dr)

@app.route('/signUP', methods = ['GET', 'POST'])
def signup():
    if request.method == 'GET':
        return render_template("sign_up.html")
    if (request.method == 'POST'):
        email = request.form['email']
        password = request.form['password']
        user = auth.create_user(email = email, password = password)
        print("Hello")

        print('Successfully fetched user data: {0}'.format(user.uid))
        # resp = make_response(render_template("/index.html"))
        # resp.set_cookie(email, "")
        # return resp
        # print(user.uid)
        # print(user.email)
        #
        # user = auth.get_user_by("email", email);
        # print("Toh main kya karoon?  Job chor doon?")
        #
        #
        # claims = auth.set_custom_user_claims(user.uid, {"admin": True})
        #
        # print(claims)
        # print(user.claims)

        return redirect("/sendaWish")


@app.route('/adminLogin', methods = ['GET', 'POST'])
def adminLogin():


    if request.method == 'GET':

        return render_template("adminLogin.html")
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
#        user = auth.get_user_by_email(email)
#        id_token = user['idToken']
        dr = BOOK_DETAILS.get()
        sign_in_with_email_and_password.sign_in_with_email_and_password(email, password)
#        return render_template("index.html");

        return render_template("index.html", dr = dr);

    # print(email);
    # user = auth.get_user_by_email(email)
    # print(user.custom_claims['admin'])
    # print("Mil toh gaya !!")
    # return render_template("admin_dashboard.html")
    # if (user.custom_claims['admin'] == True):
    #
    #     print(sendaWishQuery)
    #     return render_template("admin_dashboard.html")
    # else:
    #     return render_template("admin_errorpage.html")
@app.route('/admin_portal', methods = ['GET'])
def adminPortal():
    if request.method == 'GET':
        uid = request.cookies.get("uid", "")
        if uid:
            if (auth.get_user(uid, app=None)):
                return render_template("admin_dashboard.html")
            else:
                return render_template("try_again.html")

        return render_template("admin_dashboard.html")

if __name__ == '__main__':
    app.run(debug=True)
